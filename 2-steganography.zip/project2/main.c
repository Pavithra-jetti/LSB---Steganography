#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "decode.h"
#include "colors.h"

OperationType check_operation_type(char *);

int main(int argc, char *argv[])
{
    EncodeInfo enc;
    DecodeInfo dec;
    if(argc < 2)
    {
        printf(RED"For encoding 4 arguments is mandatory and 5th is optional as [./a.out -e .bmp .secret optional].\n"RESET);
        printf(RED"For decoding 3 arguments is mandatory 4th is optional[./a.out -d .bmp optional]\n"RESET);
        return 0;
    }
    OperationType n = check_operation_type(argv[1]);
    if(n == e_encode)
    {
        if(argc != 4 && argc != 5){
            printf(RED"Insufficient arguments for encoding.\n"RESET);
            return 0;
        }
        if(read_and_validate_encode_args(argv, &enc) == e_failure){
            printf(RED"Encoding is not possible.\n"RESET);
            return 0;
        }
        if(do_encoding(&enc) == e_failure){
            printf(RED"Encoding failed.\n"RESET);
            return 0;
        }
    }
    else if(n == e_decode){
        if(argc != 3 && argc !=4){
            printf(RED"Insufficient arguments for decoding.\n"RESET);
            return 0;
        }
        if(read_and_validate_decode_args(argc,argv,&dec)==e_failure){
            printf(RED"Decoding is not possible.\n"RESET);
            return 0;
        }
        if(do_decoding(&dec)==e_failure){
            printf(RED"Decoding failed.\n"RESET);
            return 0;
        }
    }
    else{
        printf(RED"Unsupported operation.\n"RESET);
    }
    return 0;
}
OperationType check_operation_type(char *symbol)
{
    int n=strcmp(symbol,"-e");
    if(n==0){
        return e_encode;
    }
    int m=strcmp(symbol,"-d");
    if(m==0){
        return e_decode;
    }
    return e_unsupported;
}
